// aniwatch.js
import DataManager from './data-manager.js';

// متغيرات عامة
let currentAnime = null;
let currentEpisode = 1;
let currentServer = null;
let animeEpisodes = { watch: {}, download: {} };
let videoPlayer = null;
let isDragging = false;
let isVolumesDragging = false;
let controlsTimeout = null;
let currentSpeed = 1;
let isControlsVisible = false;
let elements = {};

const CACHE_KEY = "animeDataCache";
const CACHE_TTL = 5 * 60 * 1000;

// دالة لتأخير الطلبات (Debounce) لتقليل الطلبات المتكررة
function debounce(func, wait) {
  let timeout;
  return function (...args) {
    clearTimeout(timeout);
    timeout = setTimeout(() => func.apply(this, args), wait);
  };
}

// تهيئة الصفحة
document.addEventListener("DOMContentLoaded", () => {
  elements = {
    loadingScreen: document.getElementById("loading-screen"),
    animeTitle: document.getElementById("anime-title"),
    playerSection: document.getElementById("player-section"),
    videoPlayer: document.getElementById("video-player"),
    videoContainer: document.querySelector(".video-container"),
    prevBtn: document.getElementById("prev-btn"),
    episodesBtn: document.getElementById("episodes-btn"),
    nextBtn: document.getElementById("next-btn"),
    currentEpisodeNum: document.getElementById("current-episode-number"),
    watchServers: document.getElementById("watch-servers"),
    downloadLinks: document.getElementById("download-links"),
    toast: document.getElementById("toast"),
    toastMessage: document.getElementById("toast-message"),
    backBtn: document.getElementById("back-btn"),
    loginBtn: document.getElementById("login-btn"),
    authText: document.getElementById("auth-text"),
    serverMessage: document.getElementById("server-message"),
    centerPlayBtn: document.querySelector(".center-play-btn"),
    videoControls: document.querySelector(".video-controls"),
    playPauseBtn: document.querySelector(".play-pause-btn"),
    volumeBtn: document.querySelector(".volume-btn"),
    skipBackBtn: document.querySelector(".skip-back-btn"),
    skipForwardBtn: document.querySelector(".skip-forward-btn"),
    speedBtn: document.querySelector(".speed-btn"),
    fullscreenBtn: document.querySelector(".fullscreen-btn"),
    exitFullscreenBtn: document.querySelector(".exit-fullscreen-btn"),
    progressContainer: document.querySelector(".progress-container"),
    progressPlayed: document.querySelector(".progress-played"),
    progressHandle: document.querySelector(".progress-handle"),
    progressBuffer: document.querySelector(".progress-buffer"),
    timeTooltip: document.querySelector(".time-tooltip"),
    currentTimeSpan: document.querySelector(".current-time"),
    durationSpan: document.querySelector(".duration"),
    volumeSlider: document.querySelector(".volume-slider"),
    speedMenu: document.querySelector(".speed-menu"),
    episodesModal: document.getElementById("episodes-modal"),
    episodesList: document.getElementById("episodes-list"),
  };

  for (const [key, value] of Object.entries(elements)) {
    if (!value && !["skipBackBtn", "skipForwardBtn"].includes(key)) {
      console.warn(`Element ${key} not found in DOM`);
    }
  }

  // تطبيق الثيم المحفوظ
  applySavedTheme();

  // مهلة زمنية لإخفاء شاشة التحميل في حالة الفشل
  const loadingTimeout = setTimeout(() => {
    if (elements.loadingScreen) {
      elements.loadingScreen.style.opacity = "0";
      elements.loadingScreen.style.visibility = "hidden";
      setTimeout(() => {
        elements.loadingScreen.style.display = "none";
        showToast("انتهت مهلة تحميل البيانات، حاول مرة أخرى لاحقًا");
      }, 800);
    }
  }, 10000); // 10 ثوانٍ

  // إخفاء شاشة التحميل بعد اكتمال تحميل الموارد
  if (elements.loadingScreen) {
    window.addEventListener("load", () => {
      clearTimeout(loadingTimeout); // إلغاء المهلة إذا تم التحميل
      elements.loadingScreen.style.opacity = "0";
      elements.loadingScreen.style.visibility = "hidden";
      setTimeout(() => {
        elements.loadingScreen.style.display = "none";
        initPage();
      }, 800);
    });
  } else {
    clearTimeout(loadingTimeout);
    initPage();
  }
});

// إدارة التخزين المؤقت
function getCachedData(animeId) {
  try {
    const cached = localStorage.getItem(`${CACHE_KEY}_${animeId}`);
    if (!cached) return null;
    const { data, timestamp } = JSON.parse(cached);
    if (Date.now() - timestamp > CACHE_TTL) {
      localStorage.removeItem(`${CACHE_KEY}_${animeId}`);
      return null;
    }
    return data;
  } catch (error) {
    console.error("Error parsing cached data:", error);
    return null;
  }
}

function setCachedData(animeId, data) {
  try {
    localStorage.setItem(
      `${CACHE_KEY}_${animeId}`,
      JSON.stringify({ data, timestamp: Date.now() })
    );
  } catch (error) {
    console.error("Error setting cached data:", error);
  }
}

function initPage() {
  const urlParams = new URLSearchParams(window.location.search);
  const animeId = urlParams.get("id");
  const episode = parseInt(urlParams.get("episode")) || 1;

  if (!animeId) {
    showToast("معرّف الأنمي غير صالح");
    if (elements.playerSection) elements.playerSection.classList.add("hidden");
    return;
  }

  currentEpisode = episode;
  setupVideoPlayer();
  fetchAnimeData(animeId);
  setupEventListeners();

  // تعطيل أزرار تسجيل الدخول لأن الأوثنتيكيشن غير مدعوم
  if (elements.authText) elements.authText.textContent = "تسجيل الدخول غير متاح";
  if (elements.loginBtn) elements.loginBtn.disabled = true;
}

// تهيئة مشغل الفيديو
function setupVideoPlayer() {
  if (!elements.videoPlayer) return;

  videoPlayer = elements.videoPlayer;

  // إخفاء عناصر التحكم افتراضيًا حتى يتم اختيار سيرفر
  if (elements.centerPlayBtn) elements.centerPlayBtn.classList.remove("show");
  if (elements.videoControls) elements.videoControls.classList.remove("show-controls");

  videoPlayer.addEventListener("loadstart", handleLoadStart);
  videoPlayer.addEventListener("loadedmetadata", handleLoadedMetadata);
  videoPlayer.addEventListener("timeupdate", handleTimeUpdate);
  videoPlayer.addEventListener("progress", handleProgress);
  videoPlayer.addEventListener("play", handlePlay);
  videoPlayer.addEventListener("pause", handlePause);
  videoPlayer.addEventListener("ended", handleVideoEnded);
  videoPlayer.addEventListener("error", handleVideoError);

  setupPlayPauseControl();
  setupProgressControl();
  setupVolumeControl();
  setupFullscreenControl();
  setupSpeedControl();
  setupSkipControl();
  setupKeyboardControls();
  setupTouchControls();
  setupControlsVisibility();
}

// التحكم في التشغيل
function setupPlayPauseControl() {
  if (elements.playPauseBtn) {
    elements.playPauseBtn.addEventListener("click", togglePlayPause);
  }
  if (elements.centerPlayBtn) {
    elements.centerPlayBtn.addEventListener("click", togglePlayPause);
  }
}

function togglePlayPause() {
  if (!videoPlayer || !videoPlayer.src) {
    showToast("اختر سيرفرًا لتشغيل الحلقة");
    return;
  }
  if (videoPlayer.paused) {
    videoPlayer.play().then(() => updatePlayPauseButton(true)).catch(() => showToast("تعذر التشغيل، اختر سيرفرًا أولاً"));
  } else {
    videoPlayer.pause();
    updatePlayPauseButton(false);
  }
  showControls();
}

function updatePlayPauseButton(isPlaying) {
  if (!videoPlayer) {
    console.warn("videoPlayer is not initialized yet, skipping play/pause button update");
    return;
  }
  const icon = isPlaying ? '<i class="fas fa-pause"></i>' : '<i class="fas fa-play"></i>';
  if (elements.playPauseBtn) elements.playPauseBtn.innerHTML = icon;
  if (elements.centerPlayBtn) {
    elements.centerPlayBtn.innerHTML = icon;
    elements.centerPlayBtn.classList.toggle("show", !isPlaying && !!videoPlayer.src);
  }
}

// شريط التقدم
function setupProgressControl() {
  if (!elements.progressContainer) return;
  elements.progressContainer.addEventListener("mousedown", startProgressDrag);
  elements.progressContainer.addEventListener("touchstart", startProgressDrag, { passive: false });
  document.addEventListener("mousemove", handleProgressDrag);
  document.addEventListener("mouseup", stopProgressDrag);
  document.addEventListener("touchmove", handleProgressDrag, { passive: false });
  document.addEventListener("touchend", stopProgressDrag);
  elements.progressContainer.addEventListener("mousemove", showTimeTooltip);
  elements.progressContainer.addEventListener("touchmove", showTimeTooltip, { passive: false });
}

function showTimeTooltip(e) {
  if (!videoPlayer || !videoPlayer.duration || !elements.timeTooltip) return;
  const rect = elements.progressContainer.getBoundingClientRect();
  const clientX = e.touches ? e.touches[0].clientX : e.clientX;
  const pos = Math.max(0, Math.min(1, (clientX - rect.left) / rect.width));
  const time = pos * videoPlayer.duration;
  elements.timeTooltip.textContent = formatTime(time);
  elements.timeTooltip.style.left = `${pos * 100}%`;
  elements.timeTooltip.style.opacity = "1";
  elements.timeTooltip.style.visibility = "visible";
  showControls();
}

function startProgressDrag(e) {
  if (!videoPlayer || !videoPlayer.duration) return;
  e.preventDefault();
  isDragging = true;
  elements.progressContainer.classList.add("dragging");
  handleProgressDrag(e);
  showControls();
}

function handleProgressDrag(e) {
  if (!isDragging || !videoPlayer || !videoPlayer.duration) return;
  e.preventDefault();
  const rect = elements.progressContainer.getBoundingClientRect();
  const clientX = e.touches ? e.touches[0].clientX : e.clientX;
  const pos = Math.max(0, Math.min(1, (clientX - rect.left) / rect.width));
  videoPlayer.currentTime = pos * videoPlayer.duration;
  updateProgressVisual(pos);
  elements.timeTooltip.textContent = formatTime(pos * videoPlayer.duration);
  elements.timeTooltip.style.left = `${pos * 100}%`;
  elements.timeTooltip.style.opacity = "1";
  elements.timeTooltip.style.visibility = "visible";
}

function stopProgressDrag() {
  if (isDragging) {
    isDragging = false;
    elements.progressContainer.classList.remove("dragging");
    if (elements.timeTooltip) {
      elements.timeTooltip.style.opacity = "0";
      elements.timeTooltip.style.visibility = "hidden";
    }
    showControls();
  }
}

// الصوت
function setupVolumeControl() {
  if (elements.volumeBtn) {
    elements.volumeBtn.removeEventListener("click", toggleMute);
    elements.volumeBtn.removeEventListener("touchstart", toggleMute);
    elements.volumeBtn.addEventListener("click", toggleMute);
    elements.volumeBtn.addEventListener("touchstart", toggleMute, { passive: false });
  }
  if (elements.volumeSlider) {
    elements.volumeSlider.removeEventListener("input", handleVolumeChange);
    elements.volumeSlider.addEventListener("input", handleVolumeChange);
    elements.volumeSlider.removeEventListener("touchstart", (e) => e.stopPropagation());
    elements.volumeSlider.addEventListener("touchstart", (e) => e.stopPropagation(), { passive: false });
    elements.volumeSlider.style.display = "inline-block";
    elements.volumeSlider.style.opacity = "1";
  } else {
    console.warn("Volume slider not found in DOM");
  }
}

function toggleMute(e) {
  e.preventDefault();
  if (!videoPlayer) return;
  videoPlayer.muted = !videoPlayer.muted;
  updateVolumeIcon();
  if (!videoPlayer.muted) {
    videoPlayer.volume = elements.volumeSlider ? parseFloat(elements.volumeSlider.value) : 1;
    updateVolumeSlider();
  }
  showControls();
}

function handleVolumeChange() {
  if (!videoPlayer || !elements.volumeSlider) return;
  videoPlayer.volume = elements.volumeSlider.value;
  videoPlayer.muted = videoPlayer.volume === 0;
  updateVolumeIcon();
}

function updateVolumeIcon() {
  if (!elements.volumeBtn || !videoPlayer) return;
  const icon = elements.volumeBtn.querySelector("i");
  if (videoPlayer.muted || videoPlayer.volume === 0) {
    icon.className = "fas fa-volume-mute";
  } else if (videoPlayer.volume > 0.5) {
    icon.className = "fas fa-volume-up";
  } else {
    icon.className = "fas fa-volume-down";
  }
}

function updateVolumeSlider() {
  if (!elements.volumeSlider) return;
  elements.volumeSlider.value = videoPlayer.muted ? 0 : videoPlayer.volume;
}

// ملء الشاشة
function setupFullscreenControl() {
  if (elements.fullscreenBtn) elements.fullscreenBtn.addEventListener("click", enterFullscreen);
  if (elements.exitFullscreenBtn) elements.exitFullscreenBtn.addEventListener("click", exitFullscreen);
  document.addEventListener("fullscreenchange", handleFullscreenChange);
  document.addEventListener("webkitfullscreenchange", handleFullscreenChange);
  document.addEventListener("mozfullscreenchange", handleFullscreenChange);
  document.addEventListener("MSFullscreenChange", handleFullscreenChange);
}

function enterFullscreen() {
  if (!elements.videoContainer) return;
  const fn =
    elements.videoContainer.requestFullscreen ||
    elements.videoContainer.webkitRequestFullscreen ||
    elements.videoContainer.mozRequestFullScreen ||
    elements.videoContainer.msRequestFullscreen;
  if (fn) {
    fn.call(elements.videoContainer)
      .then(() => {
        if (screen.orientation && screen.orientation.lock) {
          screen.orientation.lock("landscape-primary").catch(() => showToast("تعذر تدوير الشاشة"));
        }
        showControls();
      })
      .catch(() => showToast("خطأ في ملء الشاشة"));
  }
}

function exitFullscreen() {
  const fn =
    document.exitFullscreen ||
    document.webkitExitFullscreen ||
    document.mozCancelFullScreen ||
    document.msExitFullscreen;
  if (fn) {
    fn.call(document)
      .then(() => {
        if (screen.orientation && screen.orientation.lock && screen.orientation.type.includes("landscape")) {
          screen.orientation.lock("portrait-primary").catch((err) => {
            console.warn("Screen orientation lock not supported or failed:", err);
          });
        }
        showControls();
      })
      .catch((err) => {
        console.error("Error exiting fullscreen:", err);
        showToast("خطأ في الخروج من ملء الشاشة");
      });
  }
}

function handleFullscreenChange() {
  const isFS = !!(
    document.fullscreenElement ||
    document.webkitFullscreenElement ||
    document.mozFullScreenElement ||
    document.msFullscreenElement
  );
  if (elements.videoContainer) elements.videoContainer.classList.toggle("fullscreen", isFS);
  if (elements.fullscreenBtn) elements.fullscreenBtn.classList.toggle("hidden", isFS);
  if (elements.exitFullscreenBtn) elements.exitFullscreenBtn.classList.toggle("hidden", !isFS);
  showControls();
}

// سرعة التشغيل
function setupSpeedControl() {
  if (elements.speedBtn) {
    elements.speedBtn.addEventListener("click", toggleSpeedMenu);
    elements.speedBtn.addEventListener("touchstart", toggleSpeedMenu, { passive: false });
  }
  if (elements.speedMenu) {
    const menuItems = elements.speedMenu.querySelectorAll(".menu-item");
    menuItems.forEach((item) => {
      item.removeEventListener("click", handleSpeedSelection);
      item.removeEventListener("touchstart", handleSpeedSelection);
      item.addEventListener("click", handleSpeedSelection);
      item.addEventListener("touchstart", handleSpeedSelection, { passive: false });
    });
  } else {
    console.warn("Speed menu not found");
  }
}

function toggleSpeedMenu(e) {
  e.preventDefault();
  e.stopPropagation();
  if (elements.speedMenu) {
    elements.speedMenu.classList.toggle("show");
    showControls();
  }
}

function handleSpeedSelection(e) {
  e.preventDefault();
  e.stopPropagation();
  const speed = parseFloat(e.target.dataset.speed);
  if (!videoPlayer || isNaN(speed)) {
    console.warn("Invalid speed or videoPlayer not initialized");
    showToast("خطأ في اختيار السرعة");
    return;
  }
  videoPlayer.playbackRate = speed;
  currentSpeed = speed;
  if (elements.speedBtn) elements.speedBtn.innerHTML = `<span>${speed}x</span>`;
  elements.speedMenu.querySelectorAll(".menu-item").forEach((i) => i.classList.remove("active"));
  e.target.classList.add("active");
  elements.speedMenu.classList.remove("show");
  showToast(`تم تغيير السرعة إلى ${speed}x`);
  // حفظ الإعدادات في localStorage بدلاً من Firebase
  localStorage.setItem('playbackSpeed', speed);
}

// تخطي
function setupSkipControl() {
  if (elements.skipBackBtn) elements.skipBackBtn.addEventListener("click", () => skipTime(-10));
  if (elements.skipForwardBtn) elements.skipForwardBtn.addEventListener("click", () => skipTime(10));
}

function skipTime(seconds) {
  if (!videoPlayer || !videoPlayer.duration) {
    showToast("لا يمكن التخطي");
    return;
  }
  const newTime = Math.max(0, Math.min(videoPlayer.duration, videoPlayer.currentTime + seconds));
  videoPlayer.currentTime = newTime;

  const indicator =
    seconds < 0
      ? document.querySelector(".skip-indicator.skip-back")
      : document.querySelector(".skip-indicator.skip-forward");
  if (indicator) {
    indicator.classList.add("active");
    setTimeout(() => {
      indicator.classList.remove("active");
    }, 500);
  }

  showControls();
}

// لوحة المفاتيح
function setupKeyboardControls() {
  document.addEventListener("keydown", (e) => {
    if (!videoPlayer || ["INPUT", "TEXTAREA"].includes(e.target.tagName)) return;
    switch (e.code) {
      case "Space":
        e.preventDefault();
        togglePlayPause();
        break;
      case "ArrowLeft":
        e.preventDefault();
        skipTime(-10);
        break;
      case "ArrowRight":
        e.preventDefault();
        skipTime(10);
        break;
      case "ArrowUp":
        e.preventDefault();
        adjustVolume(0.1);
        break;
      case "ArrowDown":
        e.preventDefault();
        adjustVolume(-0.1);
        break;
      case "KeyM":
        e.preventDefault();
        toggleMute();
        break;
      case "KeyF":
        e.preventDefault();
        enterFullscreen();
        break;
      case "Escape":
        if (document.fullscreenElement) exitFullscreen();
        break;
    }
  });
}

function adjustVolume(delta) {
  if (!videoPlayer) return;
  videoPlayer.volume = Math.max(0, Math.min(1, videoPlayer.volume + delta));
  videoPlayer.muted = false;
  showToast(`مستوى الصوت: ${Math.round(videoPlayer.volume * 100)}%`);
}

// التحكم باللمس
function setupTouchControls() {
  if (!elements.videoContainer) return;
  let lastTap = 0,
    tapCount = 0;
  elements.videoContainer.addEventListener(
    "touchstart",
    (e) => {
      if (
        e.target.closest(".video-controls") ||
        e.target.closest(".center-play-btn") ||
        e.target.closest("#episodes-btn") ||
        e.target.closest("#prev-btn") ||
        e.target.closest("#next-btn")
      ) {
        console.log("Touch ignored on controls or episode buttons");
        return;
      }

      e.preventDefault();
      const now = Date.now();
      if (now - lastTap < 300) {
        tapCount++;
        if (tapCount === 2) {
          handleDoubleTap(e);
          tapCount = 0;
        }
      } else {
        tapCount = 1;
        setTimeout(() => {
          if (tapCount === 1 && videoPlayer.src) {
            console.log("Single tap detected, toggling controls");
            toggleControlsVisibility();
            tapCount = 0;
          }
        }, 300);
      }
      lastTap = now;
    },
    { passive: false }
  );
}

function handleDoubleTap(e) {
  e.preventDefault();
  const rect = elements.videoContainer.getBoundingClientRect();
  const tapX = e.touches[0].clientX - rect.left;
  const w = rect.width;
  if (tapX < w * 0.3) {
    skipTime(-10);
    console.log("Double tap: Skip back 10 seconds");
  } else if (tapX > w * 0.7) {
    skipTime(10);
    console.log("Double tap: Skip forward 10 seconds");
  } else {
    togglePlayPause();
    console.log("Double tap: Toggle play/pause");
  }
}

// إدارة التحكمات
function setupControlsVisibility() {
  if (!elements.videoContainer) return;

  elements.videoContainer.addEventListener("mousemove", showControls);
  elements.videoContainer.addEventListener("mouseleave", hideControlsDelayed);
  elements.videoContainer.addEventListener("click", (e) => {
    if (
      e.target.closest(".video-controls") ||
      e.target.closest(".center-play-btn") ||
      e.target.closest(".skip-indicator") ||
      e.target.closest(".settings-menu")
    ) {
      return;
    }
    toggleControlsVisibility();
  });
}

function showControls() {
  if (!elements.videoContainer || !videoPlayer.src) return;
  clearTimeout(controlsTimeout);
  elements.videoContainer.classList.add("show-controls");
  isControlsVisible = true;
  if (videoPlayer && !videoPlayer.paused && !isDragging && !isVolumesDragging) {
    controlsTimeout = setTimeout(() => {
      elements.videoContainer.classList.remove("show-controls");
      isControlsVisible = false;
    }, 3000);
  }
}

function hideControlsDelayed() {
  if (!isDragging && !isVolumesDragging && !elements.speedMenu.classList.contains("show")) {
    controlsTimeout = setTimeout(() => {
      if (elements.videoContainer) {
        elements.videoContainer.classList.remove("show-controls");
        isControlsVisible = false;
        if (elements.speedMenu) elements.speedMenu.classList.remove("show");
      }
    }, 500);
  }
}

function toggleControlsVisibility() {
  if (!elements.videoContainer || !videoPlayer.src) return;
  if (elements.speedMenu.classList.contains("show")) {
    elements.speedMenu.classList.remove("show");
    return;
  }
  if (isControlsVisible) {
    elements.videoContainer.classList.remove("show-controls");
    isControlsVisible = false;
    clearTimeout(controlsTimeout);
  } else {
    elements.videoContainer.classList.add("show-controls");
    isControlsVisible = true;
    clearTimeout(controlsTimeout);
    if (videoPlayer && !videoPlayer.paused) {
      controlsTimeout = setTimeout(() => {
        elements.videoContainer.classList.remove("show-controls");
        isControlsVisible = false;
      }, 3000);
    }
  }
}

function hideMenus() {
  if (elements.speedMenu) elements.speedMenu.classList.remove("show");
}

// أحداث الفيديو
function handleLoadStart() {
  elements.serverMessage?.classList.add("hidden");
}

function handleLoadedMetadata() {
  updateTimeDisplay();
  restoreTime();
}

function handleTimeUpdate() {
  if (!isDragging) {
    updateTimeDisplay();
    updateProgressBar();
  }
  if (currentAnime && currentEpisode && Math.floor(videoPlayer.currentTime) % 30 === 0) {
    localStorage.setItem(`progress_${currentAnime.id}_${currentEpisode}`, videoPlayer.currentTime);
  }
}

function handleProgress() {
  updateBufferBar();
}

function handlePlay() {
  updatePlayPauseButton(true);
  showControls();
}

function handlePause() {
  updatePlayPauseButton(false);
  if (currentAnime && currentEpisode) {
    localStorage.setItem(`progress_${currentAnime.id}_${currentEpisode}`, videoPlayer.currentTime);
  }
}

function handleVideoEnded() {
  updatePlayPauseButton(false);
  const eps = Object.keys(animeEpisodes.watch)
    .map(Number)
    .sort((a, b) => a - b);
  const idx = eps.indexOf(currentEpisode);
  if (idx !== -1 && idx < eps.length - 1) {
    showToast("سيتم الانتقال للحلقة التالية خلال 5 ثواني...");
    setTimeout(() => changeEpisode(1), 5000);
  }
}

function handleVideoError() {
  if (!videoPlayer.src || videoPlayer.src === window.location.href) {
    console.log("Ignoring video error due to empty or unset source");
    elements.serverMessage?.classList.remove("hidden");
    return;
  }
  if (videoPlayer.readyState >= 2) {
    console.log("Video is playable, ignoring error");
    return;
  }
  console.error("Video error:", videoPlayer.error);
  showToast("تعذر التشغيل");
  elements.serverMessage?.classList.remove("hidden");
}

function updateTimeDisplay() {
  if (!videoPlayer) return;
  const ct = videoPlayer.currentTime || 0;
  const dur = videoPlayer.duration || 0;
  if (elements.currentTimeSpan) elements.currentTimeSpan.textContent = formatTime(ct);
  if (elements.durationSpan) elements.durationSpan.textContent = formatTime(dur);
}

function updateProgressBar() {
  if (!videoPlayer || !videoPlayer.duration) return;
  const progress = videoPlayer.currentTime / videoPlayer.duration;
  updateProgressVisual(progress);
}

function updateBufferBar() {
  if (!videoPlayer || !videoPlayer.duration || !elements.progressBuffer) return;
  const buffered = videoPlayer.buffered;
  if (buffered.length > 0) {
    const end = buffered.end(buffered.length - 1);
    elements.progressBuffer.style.width = `${(end / videoPlayer.duration) * 100}%`;
  }
}

function restoreTime() {
  if (!currentAnime || !currentEpisode) return;
  const saved = localStorage.getItem(`progress_${currentAnime.id}_${currentEpisode}`);
  if (saved && parseFloat(saved) > 10) videoPlayer.currentTime = parseFloat(saved);
}

// جلب البيانات
async function fetchAnimeData(animeId) {
  try {
    const cached = getCachedData(animeId);
    if (cached) {
      currentAnime = cached;
      currentAnime.id = animeId;
      animeEpisodes = currentAnime.episodes || { watch: {}, download: {} };
      console.log("Cached animeEpisodes:", JSON.stringify(animeEpisodes));
      updateAnimeUI();
      selectEpisode(currentEpisode);
      return;
    }

    const { data } = await DataManager.getAnimeList();
    // افتراض أن البيانات عبارة عن مصفوفة تحتوي على كائنات الأنمي
    // يجب تعديل هذا الجزء إذا كانت بنية البيانات مختلفة
    currentAnime = data.find(anime => anime.id === animeId);
    if (!currentAnime) {
      showToast("الأنمي غير موجود");
      elements.watchServers && (elements.watchServers.innerHTML = '<div class="no-servers">الأنمي غير متاح</div>');
      elements.downloadLinks && (elements.downloadLinks.innerHTML = '<div class="no-downloads">الأنمي غير متاح</div>');
      elements.playerSection && elements.playerSection.classList.add("hidden");
      return;
    }
    currentAnime.id = animeId;
    animeEpisodes = currentAnime.episodes || { watch: {}, download: {} };
    console.log("Fetched animeEpisodes:", JSON.stringify(animeEpisodes));
    setCachedData(animeId, currentAnime);
    updateAnimeUI();
    selectEpisode(currentEpisode);
  } catch (e) {
    console.error("Error fetching anime data:", e);
    showToast("حدث خطأ أثناء جلب البيانات");
  }
}

function updateAnimeUI() {
  if (elements.animeTitle) elements.animeTitle.textContent = currentAnime.title || "غير معروف";
  if (elements.playerSection) elements.playerSection.classList.remove("hidden");
}

// اختيار حلقة
function selectEpisode(episodeNum) {
  if (videoPlayer) {
    videoPlayer.pause();
    videoPlayer.src = "";
  }
  if (elements.serverMessage) elements.serverMessage.classList.remove("hidden");
  if (elements.centerPlayBtn) elements.centerPlayBtn.classList.remove("show");
  if (elements.videoControls) elements.videoControls.classList.remove("show-controls");
  currentEpisode = episodeNum;
  if (elements.currentEpisodeNum) elements.currentEpisodeNum.textContent = currentEpisode;
  updateServers();
  updateDownloadLinks();
  updateURL();
  resetPlayerControls();
}

function resetPlayerControls() {
  if (!videoPlayer) {
    console.warn("videoPlayer is not initialized, skipping resetPlayerControls");
    return;
  }
  updateProgressVisual(0);
  if (elements.progressPlayed) elements.progressPlayed.style.width = "0%";
  if (elements.currentTimeSpan) elements.currentTimeSpan.textContent = "00:00";
  if (elements.durationSpan) elements.durationSpan.textContent = "00:00";
  updatePlayPauseButton(false);
}

function updateURL() {
  const url = `${window.location.pathname}?id=${currentAnime.id}&episode=${currentEpisode}`;
  window.history.pushState({}, "", url);
}

// السيرفرات والتحميل
function updateServers() {
  const groups = {
    "1080p": document.querySelector('.servers-list[data-quality="1080p"]'),
    "720p": document.querySelector('.servers-list[data-quality="720p"]'),
    "360p": document.querySelector('.servers-list[data-quality="360p"]'),
    "240p": document.querySelector('.servers-list[data-quality="240p"]'),
  };
  Object.values(groups).forEach((g) => g && (g.innerHTML = ""));
  if (!animeEpisodes.watch || !animeEpisodes.watch[currentEpisode.toString()]) {
    elements.watchServers && (elements.watchServers.innerHTML = '<div class="no-servers">لا توجد سيرفرات لهذه الحلقة</div>');
    return;
  }
  const servers = animeEpisodes.watch[currentEpisode.toString()] || [];
  servers.forEach((srv, i) => {
    const btn = document.createElement("button");
    btn.className = `server-btn ${i === 0 ? "active" : ""}`;
    btn.textContent = srv.name || `سيرفر ${i + 1}`;
    btn.dataset.url = srv.url;
    btn.addEventListener("click", (e) => {
      e.preventDefault();
      if (!srv.url) return showToast("رابط غير صالح");
      document.querySelectorAll(".server-btn").forEach((b) => b.classList.remove("active"));
      btn.classList.add("active");
      currentServer = srv.url;
      videoPlayer.src = srv.url;
      videoPlayer.play().catch(() => showToast("تعذر تشغيل السيرفر"));
      elements.serverMessage?.classList.add("hidden");
      showControls();
    });
    const quality = srv.quality || "720p";
    if (groups[quality]) groups[quality].appendChild(btn);
  });
}

function updateDownloadLinks() {
  const groups = {
    "1080p": document.querySelector('.download-list[data-quality="1080p"]'),
    "720p": document.querySelector('.download-list[data-quality="720p"]'),
    "360p": document.querySelector('.download-list[data-quality="360p"]'),
    "240p": document.querySelector('.download-list[data-quality="240p"]'),
  };
  Object.values(groups).forEach((g) => g && (g.innerHTML = ""));
  if (!animeEpisodes.download || !animeEpisodes.download[currentEpisode.toString()]) {
    elements.downloadLinks && (elements.downloadLinks.innerHTML = '<div class="no-downloads">لا توجد روابط تحميل لهذه الحلقة</div>');
    return;
  }
  const links = animeEpisodes.download[currentEpisode.toString()] || [];
  links.forEach((link) => {
    const a = document.createElement("a");
    a.className = "download-link";
    a.href = link.url;
    a.textContent = link.name || `تحميل ${link.quality || "720p"}`;
    a.target = "_blank";
    const quality = link.quality || "720p";
    if (groups[quality]) groups[quality].appendChild(a);
  });
}

// نافذة الحلقات
function setupEventListeners() {
  if (elements.prevBtn) {
    elements.prevBtn.addEventListener("click", debounce(() => changeEpisode(-1), 300));
  }
  if (elements.nextBtn) {
    elements.nextBtn.addEventListener("click", debounce(() => changeEpisode(1), 300));
  }
  if (elements.episodesBtn) {
    elements.episodesBtn.addEventListener("click", showEpisodesModal);
  }
  if (elements.backBtn) {
    elements.backBtn.addEventListener("click", () => {
      if (window.history.length > 1) {
        window.history.back();
      } else {
        window.location.href = "index.html";
      }
    });
  }
  const closeModalBtn = document.querySelector(".close-modal");
  if (closeModalBtn) {
    closeModalBtn.addEventListener("click", () => elements.episodesModal.classList.remove("active"));
  }
}

function changeEpisode(delta) {
  const eps = Object.keys(animeEpisodes.watch)
    .map(Number)
    .sort((a, b) => a - b);
  const idx = eps.indexOf(currentEpisode);
  if (idx !== -1 && eps[idx + delta]) {
    selectEpisode(eps[idx + delta]);
    showToast(`الانتقال إلى الحلقة ${eps[idx + delta]}`);
  } else {
    showToast(delta > 0 ? "لا توجد حلقة تالية" : "لا توجد حلقة سابقة");
  }
}

function showEpisodesModal() {
  if (!elements.episodesList) return;
  elements.episodesList.innerHTML = "";
  const eps = Object.keys(animeEpisodes.watch)
    .map(Number)
    .sort((a, b) => a - b);
  eps.forEach((ep) => {
    const div = document.createElement("div");
    div.className = `episode-item ${ep === currentEpisode ? "active" : ""}`;
    div.textContent = `الحلقة ${ep}`;
    div.addEventListener("click", () => {
      selectEpisode(ep);
      elements.episodesModal.classList.remove("active");
      showToast(`الانتقال إلى الحلقة ${ep}`);
    });
    elements.episodesList.appendChild(div);
  });
  elements.episodesModal.classList.add("active");
}

// أدوات مساعدة
function updateProgressVisual(progress) {
  if (elements.progressPlayed) elements.progressPlayed.style.width = `${progress * 100}%`;
  if (elements.progressHandle) elements.progressHandle.style.left = `${progress * 100}%`;
}

function formatTime(seconds) {
  if (isNaN(seconds)) return "00:00";
  const min = Math.floor(seconds / 60);
  const sec = Math.floor(seconds % 60);
  return `${min.toString().padStart(2, "0")}:${sec.toString().padStart(2, "0")}`;
}

function showToast(message) {
  if (elements.toastMessage && elements.toast) {
    elements.toastMessage.textContent = message;
    elements.toast.classList.add("show");
    setTimeout(() => elements.toast.classList.remove("show"), 3000);
  }
}