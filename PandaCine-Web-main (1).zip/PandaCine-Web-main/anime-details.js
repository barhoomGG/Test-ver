import DataManager from './data-manager.js';

document.addEventListener("DOMContentLoaded", () => {
  // تطبيق الثيم المحفوظ
  function applySavedTheme() {
    const savedTheme = localStorage.getItem("theme");
    if (savedTheme === "purple") {
      document.documentElement.classList.add("theme-purple");
    } else {
      document.documentElement.classList.remove("theme-purple");
    }
  }

  applySavedTheme();

  const params = new URLSearchParams(window.location.search);
  const animeId = params.get("id");
  const loadingScreen = document.getElementById("loadingScreen");
  const poster = document.getElementById("animePoster");
  const title = document.getElementById("animeTitle");
  const genres = document.getElementById("animeGenres");
  const rating = document.getElementById("animeRating");
  const episodeCount = document.getElementById("episodeCount");
  const animeStatus = document.getElementById("animeStatus");
  const description = document.getElementById("animeDescription");
  const watchBtn = document.getElementById("watchNowBtn");
  const favoriteBtn = document.getElementById("favoriteBtn");
  const watchLaterBtn = document.getElementById("watchLaterBtn");
  const notifications = document.getElementById("notifications");
  const backBtn = document.getElementById("backBtn");
  const shareBtn = document.getElementById("shareBtn");
  const userRatingValue = document.getElementById("userRatingValue");
  const settingsBtn = document.getElementById("settingsBtn");
  const settingsMenu = document.getElementById("settingsMenu");
  const loginLink = document.getElementById("loginLink");
  const logoutLink = document.getElementById("logoutLink");
  const aboutLink = document.getElementById("aboutLink");
  const logo = document.getElementById("logo");
  const commentForm = document.getElementById("commentFormContainer");
  const commentInput = document.getElementById("commentInput");
  const submitCommentBtn = document.getElementById("submitCommentBtn");
  const commentsList = document.getElementById("commentsList");
  const loginToComment = document.getElementById("loginToComment");

  const isLoggedIn = localStorage.getItem('isLoggedIn') === 'true';

  // إعداد واجهة المستخدم بناءً على حالة تسجيل الدخول
  if (isLoggedIn) {
    if (commentForm) commentForm.style.display = "block";
    if (loginToComment) loginToComment.style.display = "none";
    if (loginLink) loginLink.style.display = "none";
    if (logoutLink) logoutLink.style.display = "block";
    if (document.querySelector(".user-name")) {
      document.querySelector(".user-name").textContent = localStorage.getItem("username") || "باندا متخفي 🐼";
    }
  } else {
    if (commentForm) commentForm.style.display = "none";
    if (loginToComment) loginToComment.style.display = "block";
    if (loginLink) loginLink.style.display = "block";
    if (logoutLink) logoutLink.style.display = "none";
    if (document.querySelector(".user-name")) {
      document.querySelector(".user-name").textContent = "زائر";
    }
  }

function showNotification(message, type = 'info') {
  const toastContainer = document.getElementById('notifications') || createToastContainer();
  const toast = document.createElement('div');
  toast.className = `toast ${type}`;
  toast.innerHTML = `
    <div class="toast-content">
      <i class="toast-icon ${getIconByType(type)}"></i>
      <span class="toast-message">${message}</span>
    </div>
    <div class="toast-progress"></div>
  `;
  
  toastContainer.appendChild(toast);
  setTimeout(() => toast.classList.add('show'), 10);
  
  setTimeout(() => {
    toast.classList.remove('show');
    setTimeout(() => toast.remove(), 300);
  }, 3000);
}

function createToastContainer() {
  const container = document.createElement('div');
  container.id = 'notifications';
  container.className = 'toast-container';
  document.body.appendChild(container);
  return container;
}

function getIconByType(type) {
  const icons = {
    'info': 'fas fa-info-circle',
    'success': 'fas fa-check-circle',
    'warning': 'fas fa-exclamation-circle',
    'error': 'fas fa-times-circle'
  };
  return icons[type] || icons['info'];
}

  // التحكم في الشريط الجانبي للإعدادات
  if (settingsBtn && settingsMenu) {
    settingsBtn.addEventListener("click", (e) => {
      e.stopPropagation();
      settingsMenu.classList.toggle("active");
      showNotification("تم فتح قائمة الإعدادات");
    });

    document.addEventListener("click", (e) => {
      if (!settingsBtn.contains(e.target) && !settingsMenu.contains(e.target)) {
        settingsMenu.classList.remove("active");
      }
    });
  }

  // النقر على الشعار
  if (logo) {
    logo.addEventListener("click", () => {
      showNotification("جارٍ العودة إلى الصفحة الرئيسية...");
      setTimeout(() => window.location.href = "index.html", 500);
    });
  }

  // زر العودة
  if (backBtn) {
    backBtn.addEventListener("click", () => {
      showNotification("جارٍ العودة إلى صفحة الأنمي...");
      setTimeout(() => window.location.href = "anime.html", 500);
    });
  }

  // زر المشاركة
  if (shareBtn) {
    shareBtn.addEventListener("click", () => {
      if (navigator.share) {
        navigator
          .share({
            title: document.title,
            url: window.location.href,
          })
          .then(() => showNotification("تمت المشاركة بنجاح!"))
          .catch(() => showNotification("حدث خطأ أثناء المشاركة"));
      } else {
        navigator.clipboard
          .writeText(window.location.href)
          .then(() => showNotification("تم نسخ الرابط!"))
          .catch(() => showNotification("حدث خطأ أثناء نسخ الرابط"));
      }
    });
  }

  // زر تسجيل الدخول
  if (loginLink) {
    loginLink.addEventListener("click", (e) => {
      e.preventDefault();
      showNotification("جارٍ الانتقال إلى صفحة تسجيل الدخول...");
      setTimeout(() => window.location.href = "login.html", 500);
      settingsMenu.classList.remove("active");
    });
  }

  // زر تسجيل الخروج
  if (logoutLink) {
    logoutLink.addEventListener("click", (e) => {
      e.preventDefault();
      localStorage.removeItem("isLoggedIn");
      localStorage.removeItem("username");
      localStorage.removeItem("authToken");
      showNotification("تم تسجيل الخروج بنجاح!");
      setTimeout(() => window.location.href = "login.html", 500);
      settingsMenu.classList.remove("active");
      // تحديث واجهة المستخدم بعد تسجيل الخروج
      if (commentForm) commentForm.style.display = "none";
      if (loginToComment) loginToComment.style.display = "block";
      if (loginLink) loginLink.style.display = "block";
      if (logoutLink) logoutLink.style.display = "none";
      if (document.querySelector(".user-name")) {
        document.querySelector(".user-name").textContent = "زائر";
      }
    });
  }

  // زر حول
  if (aboutLink) {
    aboutLink.addEventListener("click", (e) => {
      e.preventDefault();
      showNotification("جارٍ الانتقال إلى صفحة حول...");
      setTimeout(() => window.location.href = "about.html", 500);
      settingsMenu.classList.remove("active");
    });
  }

  // زر المفضلة
  if (favoriteBtn) {
    const updateFavoriteButtonState = () => {
      const favoriteIds = JSON.parse(localStorage.getItem("favorites") || "[]");
      favoriteBtn.classList.toggle("active", favoriteIds.includes(animeId));
    };

    favoriteBtn.addEventListener("click", () => {
      if (!isLoggedIn) {
        showNotification("يجب تسجيل الدخول لإضافة إلى المفضلة");
        return;
      }
      let favoriteIds = JSON.parse(localStorage.getItem("favorites") || "[]");
      if (favoriteIds.includes(animeId)) {
        favoriteIds = favoriteIds.filter((id) => id !== animeId);
        showNotification("تمت إزالة الأنمي من المفضلة");
      } else {
        favoriteIds.push(animeId);
        showNotification("تمت إضافة الأنمي إلى المفضلة");
      }
      localStorage.setItem("favorites", JSON.stringify(favoriteIds));
      updateFavoriteButtonState();
    });

    updateFavoriteButtonState();
  }

  // زر مشاهدة لاحقًا
  if (watchLaterBtn) {
    const updateWatchLaterButtonState = () => {
      const watchLaterIds = JSON.parse(localStorage.getItem("watchLater") || "[]");
      watchLaterBtn.classList.toggle("active", watchLaterIds.includes(animeId));
    };

    watchLaterBtn.addEventListener("click", () => {
      if (!isLoggedIn) {
        showNotification("يجب تسجيل الدخول لإضافة إلى مشاهدة لاحقًا");
        return;
      }
      let watchLaterIds = JSON.parse(localStorage.getItem("watchLater") || "[]");
      if (watchLaterIds.includes(animeId)) {
        watchLaterIds = watchLaterIds.filter((id) => id !== animeId);
        showNotification("تمت إزالة الأنمي من مشاهدة لاحقًا");
      } else {
        watchLaterIds.push(animeId);
        showNotification("تمت إضافة الأنمي إلى مشاهدة لاحقًا");
      }
      localStorage.setItem("watchLater", JSON.stringify(watchLaterIds));
      updateWatchLaterButtonState();
    });

    updateWatchLaterButtonState();
  }

  // نظام التقييم
  if (userRatingValue) {
    userRatingValue.addEventListener("click", () => {
      if (!isLoggedIn) {
        showNotification("يجب تسجيل الدخول");
        return;
      }
      showNotification("نظام التقييم سيتوفر قريبًا بعد إضافة تسجيل الدخول عبر API");
    });
  }

  // نظام التعليقات (محلي باستخدام localStorage)
  if (submitCommentBtn) {
    submitCommentBtn.addEventListener("click", () => {
      if (!isLoggedIn) {
        showNotification("يجب تسجيل الدخول للتعليق");
        return;
      }
      const content = commentInput?.value.trim();
      if (!content) {
        showNotification("اكتب تعليقًا قبل الإرسال");
        return;
      }

      const comments = JSON.parse(localStorage.getItem(`comments_${animeId}`) || "[]");
      const username = localStorage.getItem("username") || "باندا متخفي 🐼";
      comments.push({
        content,
        username,
        createdAt: new Date().toISOString(),
      });
      localStorage.setItem(`comments_${animeId}`, JSON.stringify(comments));
      commentInput.value = "";
      showNotification("تم إرسال التعليق");
      loadComments();
    });
  }

  function loadComments() {
    if (!commentsList) {
      console.error("عنصر commentsList غير موجود في DOM");
      return;
    }
    const comments = JSON.parse(localStorage.getItem(`comments_${animeId}`) || "[]");
    commentsList.innerHTML = "";
    if (comments.length === 0) {
      commentsList.innerHTML = "<p>لا توجد تعليقات بعد.</p>";
      return;
    }
    comments.sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt)).forEach((comment) => {
      const div = document.createElement("div");
      div.className = "comment";
      div.innerHTML = `
        <p><strong>${comment.username}</strong>:</p>
        <p>${comment.content}</p>
      `;
      commentsList.appendChild(div);
    });
  }

  // دالة ترجمة الوصف باستخدام LibreTranslate API
  async function translateDescription(desc) {
    if (!desc || desc === "لا يوجد وصف.") return desc;
    try {
      const res = await fetch('https://libretranslate.de/translate', {
        method: 'POST',
        body: JSON.stringify({
          q: desc,
          source: "en",
          target: "ar",
          format: "text"
        }),
        headers: { 'Content-Type': 'application/json' }
      });
      const data = await res.json();
      return data.translatedText || desc;
    } catch (e) {
      console.error("خطأ في الترجمة:", e);
      return desc;
    }
  }

  // دالة ترجمة الحالة
  function translateStatus(status) {
    const statusMap = {
      'ongoing': 'مستمر',
      'completed': 'مكتمل',
      'dropped': 'متوقف',
      'soon': 'قريبًا',
    };
    return statusMap[status.toLowerCase()] || status;
  }

  // تحميل بيانات الأنمي
  async function loadAnimeData() {
    // مهلة زمنية لإخفاء شاشة التحميل كحد أقصى
    const loadingTimeout = setTimeout(() => {
      if (loadingScreen) {
        loadingScreen.classList.add("hidden");
        setTimeout(() => loadingScreen.remove(), 500);
        showNotification("انتهت مهلة تحميل البيانات، حاول مرة أخرى لاحقًا");
        console.error("Loading timeout after 5 seconds");
      }
    }, 5000); // 5 ثوانٍ

    // فحص وجود عناصر DOM
    if (!poster || !title || !rating || !description || !animeStatus || !episodeCount || !genres) {
      console.error("عنصر/عناصر DOM مفقودة:", {
        poster: !!poster,
        title: !!title,
        rating: !!rating,
        description: !!description,
        animeStatus: !!animeStatus,
        episodeCount: !!episodeCount,
        genres: !!genres,
      });
      showNotification("خطأ في تحميل واجهة المستخدم");
      clearTimeout(loadingTimeout);
      if (loadingScreen) {
        loadingScreen.classList.add("hidden");
        setTimeout(() => loadingScreen.remove(), 500);
      }
      loadComments();
      return;
    }

    // فحص البيانات المخزنة
    const cachedData = localStorage.getItem(`anime_${animeId}`);
    const TTL = 60000; // 1 دقيقة
    if (cachedData) {
      try {
        const animeData = JSON.parse(cachedData);
        if (!animeData || !animeData.id || typeof animeData !== "object") {
          throw new Error("البيانات المخزنة غير صالحة");
        }
        if (Date.now() - animeData.timestamp < TTL) {
          console.log("استخدام البيانات المخزنة من localStorage:", animeData);
          await updateUI(animeData);
          loadComments();
          clearTimeout(loadingTimeout);
          if (loadingScreen) {
            loadingScreen.classList.add("hidden");
            setTimeout(() => loadingScreen.remove(), 500);
          }
          return;
        }
      } catch (error) {
        console.error("خطأ في تحليل البيانات المخزنة:", error);
        localStorage.removeItem(`anime_${animeId}`); // إزالة البيانات التالفة
      }
    }

    try {
      console.log("جلب البيانات من DataManager...");
      const result = await DataManager.getAnimeList();
      console.log("استجابة DataManager:", result);
      if (!result || !Array.isArray(result.data)) {
        throw new Error("استجابة DataManager غير صالحة أو فارغة");
      }
      const anime = result.data.find((item) => item.id === animeId);
      if (!anime) {
        console.warn(`لم يتم العثور على الأنمي بمعرف: ${animeId}`);
        if (title) title.textContent = "الأنمي غير موجود.";
        showNotification("لم يتم العثور على الأنمي");
        clearTimeout(loadingTimeout);
        if (loadingScreen) {
          loadingScreen.classList.add("hidden");
          setTimeout(() => loadingScreen.remove(), 500);
        }
        loadComments();
        return;
      }

      const animeData = {
        id: anime.id || animeId,
        image: anime.cover || anime.poster || "https://via.placeholder.com/800x450?text=No+Image",
        title: anime.title || "بدون عنوان",
        imdb: anime.rating ? Number(anime.rating).toFixed(1) : "0.0",
        description: anime.description || "لا يوجد وصف.",
        status: anime.state || "غير معروف",
        totalEpisodes: anime.totalEpisodes ? `${anime.totalEpisodes} حلقة` : "غير معروف",
        genres: Array.isArray(anime.category) ? anime.category : ["لا توجد تصنيفات"],
        currentEpisode: anime.currentEpisode || 0,
        timestamp: Date.now(),
      };
      console.log("تخزين البيانات في localStorage:", animeData);
      localStorage.setItem(`anime_${animeId}`, JSON.stringify(animeData));
      await updateUI(animeData);
      loadComments();
      clearTimeout(loadingTimeout);
      if (loadingScreen) {
        loadingScreen.classList.add("hidden");
        setTimeout(() => loadingScreen.remove(), 500);
      }
    } catch (error) {
      console.error("خطأ في جلب بيانات الأنمي:", error);
      if (title) title.textContent = "حدث خطأ أثناء تحميل الأنمي.";
      showNotification("حدث خطأ أثناء تحميل البيانات");
      clearTimeout(loadingTimeout);
      if (loadingScreen) {
        loadingScreen.classList.add("hidden");
        setTimeout(() => loadingScreen.remove(), 500);
      }
      loadComments();
    }
  }

  async function updateUI(animeData) {
    console.log("تحديث واجهة المستخدم بالبيانات:", animeData);
    if (poster) poster.src = animeData.image || "https://via.placeholder.com/800x450?text=No+Image";
    if (title) title.textContent = animeData.title || "بدون عنوان";
    if (rating) rating.textContent = animeData.imdb || "0.0";
    let transDesc = animeData.translatedDescription;
    if (!transDesc) {
      transDesc = await translateDescription(animeData.description);
      animeData.translatedDescription = transDesc;
      localStorage.setItem(`anime_${animeId}`, JSON.stringify(animeData));
    }
    if (description) description.textContent = transDesc || "لا يوجد وصف.";
    if (animeStatus) animeStatus.textContent = translateStatus(animeData.status) || "غير معروف";
    if (episodeCount) episodeCount.textContent = animeData.totalEpisodes || "غير معروف";
    if (genres) {
      genres.innerHTML = "";
      if (Array.isArray(animeData.genres) && animeData.genres.length > 0) {
        animeData.genres.forEach((genre) => {
          const span = document.createElement("span");
          span.textContent = genre;
          genres.appendChild(span);
        });
      } else {
        genres.textContent = "لا توجد تصنيفات";
      }
    }
  }

  // زر مشاهدة الآن
  if (watchBtn) {
    watchBtn.addEventListener("click", () => {
      showNotification("جارٍ الانتقال إلى صفحة المشاهدة...");
      setTimeout(() => {
        const cachedData = localStorage.getItem(`anime_${animeId}`);
        let currentEpisode = 0;
        if (cachedData) {
          try {
            const animeData = JSON.parse(cachedData);
            currentEpisode = animeData.currentEpisode || 0;
          } catch (error) {
            console.error("خطأ في تحليل بيانات المشاهدة المخزنة:", error);
          }
        }
        if (currentEpisode && parseInt(currentEpisode) > 0) {
          window.location.href = `aniwatch.html?id=${animeId}`;
        } else {
          showNotification("لا توجد حلقات متاحة حالياً");
        }
      }, 500);
    });
  }

  if (!animeId) {
    console.warn("لم يتم العثور على معرف الأنمي في عنوان URL");
    if (title) title.textContent = "لم يتم العثور على الأنمي.";
    showNotification("لم يتم العثور على معرف الأنمي");
    if (loadingScreen) {
      loadingScreen.classList.add("hidden");
      setTimeout(() => loadingScreen.remove(), 500);
    }
    loadComments();
    return;
  }

  console.log("بدء تحميل بيانات الأنمي للمعرف:", animeId);
  loadAnimeData();
});